# Combo II-DLD (xc7s75fgga484-1) / MAIN CLOCK 50 MHz / 보드 최상위: dac
# 출처: lab00/Xilinx S7 Pin Map.xlsx (DLD-Spartan7-Peripheral, DA Converter·DIP·KEY·LED)
# rst_p = KEY01(1번, SW4는 PUSH SWITCH), add_sel = DIP_SW1 (OFF: 채널 A, ON: 채널 B)
# 기본 UPDATE_CYCLES=500000 → 10 ms마다 1씩 증가, 0→255 한 바퀴 2.56 s
set_property PACKAGE_PIN B6 [get_ports clk_50mhz]
set_property PACKAGE_PIN K4 [get_ports rst_p]
set_property PACKAGE_PIN Y1 [get_ports add_sel]

set_property PACKAGE_PIN E1 [get_ports dac_csn]
set_property PACKAGE_PIN F4 [get_ports dac_ldacn]
set_property PACKAGE_PIN G4 [get_ports dac_wen]
set_property PACKAGE_PIN G2 [get_ports dac_a_b]

set_property PACKAGE_PIN E3 [get_ports {dac_d[0]}]
set_property PACKAGE_PIN E5 [get_ports {dac_d[1]}]
set_property PACKAGE_PIN D2 [get_ports {dac_d[2]}]
set_property PACKAGE_PIN D5 [get_ports {dac_d[3]}]
set_property PACKAGE_PIN C2 [get_ports {dac_d[4]}]
set_property PACKAGE_PIN C4 [get_ports {dac_d[5]}]
set_property PACKAGE_PIN B1 [get_ports {dac_d[6]}]
set_property PACKAGE_PIN B3 [get_ports {dac_d[7]}]

# DAC에 쓴 값: LED_D1~D8 → led_out[7:0]
set_property PACKAGE_PIN L4 [get_ports {led_out[7]}]
set_property PACKAGE_PIN M4 [get_ports {led_out[6]}]
set_property PACKAGE_PIN M2 [get_ports {led_out[5]}]
set_property PACKAGE_PIN N7 [get_ports {led_out[4]}]
set_property PACKAGE_PIN M7 [get_ports {led_out[3]}]
set_property PACKAGE_PIN M3 [get_ports {led_out[2]}]
set_property PACKAGE_PIN M1 [get_ports {led_out[1]}]
set_property PACKAGE_PIN N5 [get_ports {led_out[0]}]

set_property IOSTANDARD LVCMOS33 [get_ports *]
create_clock -name clk_50mhz -period 20.000 [get_ports clk_50mhz]
set_false_path -from [get_ports {rst_p add_sel}]
