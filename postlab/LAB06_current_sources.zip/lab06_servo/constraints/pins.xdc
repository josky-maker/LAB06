# Combo II-DLD (xc7s75fgga484-1) / MAIN CLOCK 50 MHz / 보드 최상위: servo_board
# 출처: lab00/Xilinx S7 Pin Map.xlsx (DLD-Spartan7-Peripheral)
# 키패드는 SW4를 PUSH SWITCH(OFF)로 둡니다. 눌렀을 때 HIGH입니다.
# rst_p = KEY01(1번), btn_left = KEY04(4번, 0.1 ms 감소), btn_right = KEY06(6번, 0.1 ms 증가)
set_property PACKAGE_PIN B6 [get_ports clk_50mhz]
set_property PACKAGE_PIN K4 [get_ports rst_p]
set_property PACKAGE_PIN N1 [get_ports btn_left]
set_property PACKAGE_PIN N6 [get_ports btn_right]

set_property PACKAGE_PIN AA22 [get_ports servo]

# 위치 단계 0~10: LED_D1~D8 → led_out[7:0]
set_property PACKAGE_PIN L4 [get_ports {led_out[7]}]
set_property PACKAGE_PIN M4 [get_ports {led_out[6]}]
set_property PACKAGE_PIN M2 [get_ports {led_out[5]}]
set_property PACKAGE_PIN N7 [get_ports {led_out[4]}]
set_property PACKAGE_PIN M7 [get_ports {led_out[3]}]
set_property PACKAGE_PIN M3 [get_ports {led_out[2]}]
set_property PACKAGE_PIN M1 [get_ports {led_out[1]}]
set_property PACKAGE_PIN N5 [get_ports {led_out[0]}]

set_property IOSTANDARD LVCMOS33 [get_ports {clk_50mhz rst_p btn_left btn_right servo led_out[*]}]
create_clock -name clk_50mhz -period 20.000 [get_ports clk_50mhz]
set_false_path -from [get_ports {rst_p btn_left btn_right}]
