`timescale 1ns/1ps
module tb_board;
    reg clk=0,rst=1,bl=0,br=0;
    always #5 clk=~clk;
    wire servo; wire [7:0] led;
    servo_board #(.CLK_HZ(100000),.DEBOUNCE_CYCLES(20)) dut(clk,rst,bl,br,servo,led);
    task press(input integer which); integer k; begin
        // 바운스 5번 후 안정 누름 50클록, 바운스 후 해제
        for(k=0;k<5;k=k+1) begin if(which) br=~br; else bl=~bl; #30; end
        if(which) br=1; else bl=1; #500;
        for(k=0;k<5;k=k+1) begin if(which) br=~br; else bl=~bl; #30; end
        if(which) br=0; else bl=0; #500;
    end endtask
    initial begin
        #50 rst=0; #100;
        if(led!==5 || dut.u_servo.u_position.pulse_us!==1500) $fatal(1,"init");
        press(1); if(led!==6 || dut.u_servo.u_position.pulse_us!==1600) $fatal(1,"one press -> one step, got %0d",led);
        press(1); press(1); press(1); press(1); press(1); if(led!==10 || dut.u_servo.u_position.pulse_us!==2000) $fatal(1,"upper limit");
        repeat(12) press(0); if(led!==0 || dut.u_servo.u_position.pulse_us!==1000) $fatal(1,"lower limit");
        $display("PASS servo_board: bouncy press = one step, LED step matches pulse_us, limits"); $finish;
    end
    initial begin #2000000; $fatal(1,"timeout"); end
endmodule
