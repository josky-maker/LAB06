`timescale 1ns/1ps
// 보드 시연용 최상위. 키패드 버튼을 한 번 누름 펄스로 바꿔 servo_ctrl에 연결합니다.
// led_out은 현재 위치 단계(0=1.0 ms ~ 10=2.0 ms)를 2진수로 보여 줍니다.
module servo_board #(parameter CLK_HZ=50_000_000, parameter DEBOUNCE_CYCLES=500_000)(
    input wire clk_50mhz,rst_p,btn_left,btn_right,
    output wire servo,
    output reg [7:0] led_out
);
    wire left_pulse,right_pulse;
    button_pulse #(.DEBOUNCE_CYCLES(DEBOUNCE_CYCLES)) u_left(clk_50mhz,rst_p,btn_left,left_pulse);
    button_pulse #(.DEBOUNCE_CYCLES(DEBOUNCE_CYCLES)) u_right(clk_50mhz,rst_p,btn_right,right_pulse);
    servo_ctrl #(.CLK_HZ(CLK_HZ)) u_servo(clk_50mhz,rst_p,left_pulse,right_pulse,servo);
    // servo_position과 같은 규칙으로 단계를 따로 셉니다(나눗셈 회로를 피하기 위함).
    always @(posedge clk_50mhz)
        if(rst_p) led_out<=8'd5;
        else if(left_pulse && !right_pulse && led_out>0) led_out<=led_out-1'b1;
        else if(right_pulse && !left_pulse && led_out<10) led_out<=led_out+1'b1;
endmodule
