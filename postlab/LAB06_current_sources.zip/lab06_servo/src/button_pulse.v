`timescale 1ns/1ps
// 버튼 원시 입력을 2단 동기화하고, DEBOUNCE_CYCLES 동안 같은 값이 유지되면
// 안정된 값으로 받아들인 뒤 LOW→HIGH 순간에 한 클록 길이의 펄스를 냅니다.
// 기본값 500_000은 50 MHz에서 10 ms입니다.
module button_pulse #(parameter DEBOUNCE_CYCLES=500_000)(
    input wire clk_50mhz,rst_p,button,
    output reg pulse
);
    (* ASYNC_REG="TRUE" *) reg [1:0] sync;
    reg stable;
    reg [31:0] count;
    always @(posedge clk_50mhz) begin
        if(rst_p) begin sync<=0; stable<=0; count<=0; pulse<=0; end
        else begin
            sync<={sync[0],button};
            pulse<=0;
            if(sync[1]==stable) count<=0;
            else if(count==DEBOUNCE_CYCLES-1) begin
                count<=0;
                stable<=sync[1];
                if(sync[1]) pulse<=1;
            end
            else count<=count+1;
        end
    end
endmodule
