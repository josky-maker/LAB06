`timescale 1ns/1ps
module servo_pwm #(parameter CLK_HZ=50_000_000)(
    input wire clk_50mhz,rst_p,
    input wire [31:0] pulse_us,
    output wire servo
);
    localparam FRAME_CYCLES=CLK_HZ/50; // 20 ms
    // 1 us당 클록 수. 50 MHz면 50이므로 나눗셈 없이 곱셈만 합니다.
    // 원래 식 pulse_us*(CLK_HZ/1000)/1000은 한 클록에 곱셈과 나눗셈을 해서
    // 50 MHz 타이밍(20 ns)을 맞추지 못했습니다(WNS -0.738 ns).
    // CLK_HZ가 1 MHz의 배수가 아닌 경우(TB의 100 kHz)는 원래 식을 씁니다.
    localparam CYCLES_PER_US=CLK_HZ/1_000_000;
    reg [31:0] count;
    reg [31:0] width_cycles;
    wire [31:0] next_width=(CYCLES_PER_US*1_000_000==CLK_HZ)
        ? pulse_us*CYCLES_PER_US
        : pulse_us*(CLK_HZ/1000)/1000;
    always @(posedge clk_50mhz) begin
        if(rst_p) begin count<=0; width_cycles<=(CLK_HZ/1000)*3/2; end
        else if(count==FRAME_CYCLES-1) begin
            count<=0;
            // 프레임 경계에서만 폭을 바꿔 중간 펄스가 잘리지 않게 합니다.
            width_cycles<=next_width;
        end
        else count<=count+1;
    end
    assign servo=!rst_p && (count<width_cycles);
endmodule

