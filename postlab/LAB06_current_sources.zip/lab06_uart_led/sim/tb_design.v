`timescale 1ns/1ps
// 과제6·7 FPGA 검증: MCU 역할로 8N1 바이트를 보내고
// PC 출력(pc_txd)으로 같은 바이트가 돌아오는지, 명령에 따라 LED1이 바뀌는지 검사합니다.
// 시뮬레이션 시간을 줄이려고 CLK_HZ=1000, BAUD=100 → 한 비트 = 10클록(100 ns)입니다.
module tb;
    // 파형 기록: build/sim/wave.vcd
    initial begin
        $dumpfile("wave.vcd");
        $dumpvars(0, tb);
    end
    localparam integer BIT_NS = 100;
    reg clk = 0, rst = 1, mcu_rxd = 1;
    always #5 clk = ~clk;
    wire pc_txd, mcu_txd;
    wire [7:0] led;
    uart_led #(.CLK_HZ(1000), .BAUD(100)) dut(clk, rst, mcu_rxd, pc_txd, mcu_txd, led);

    // MCU PC10 역할: 시작 비트, LSB부터 8비트, 정지 비트
    task send_byte(input [7:0] b);
        integer k;
        begin
            mcu_rxd = 0; #(BIT_NS);
            for (k = 0; k < 8; k = k + 1) begin mcu_rxd = b[k]; #(BIT_NS); end
            mcu_rxd = 1; #(BIT_NS);
        end
    endtask

    // PC 역할: pc_txd를 비트 중앙에서 읽어 한 바이트를 복원
    reg [7:0] echoed;
    integer echoes = 0;
    always @(negedge pc_txd) if (!rst) begin : receive
        integer k;
        #(BIT_NS/2);
        if (pc_txd !== 0) $fatal(1, "echo start bit");
        for (k = 0; k < 8; k = k + 1) begin #(BIT_NS); echoed[k] = pc_txd; end
        #(BIT_NS);
        if (pc_txd !== 1) $fatal(1, "echo stop bit");
        echoes = echoes + 1;
    end

    task check(input [7:0] b, input expected_led1);
        integer echoes_before;
        begin
            echoes_before = echoes;
            send_byte(b);
            wait (echoes == echoes_before + 1);
            #(BIT_NS);
            if (echoed !== b) $fatal(1, "echo sent=%h got=%h", b, echoed);
            if (led[7] !== expected_led1) $fatal(1, "cmd LED after %h expected=%0d got=%0d", b, expected_led1, led[7]);
            if (led[6:0] !== b[6:0]) $fatal(1, "last data LED after %h got=%h", b, led[6:0]);
            if (mcu_txd !== pc_txd) $fatal(1, "mcu_txd mirror");
        end
    endtask

    initial begin
        #20;
        if (pc_txd !== 1 || led !== 0) $fatal(1, "reset state");
        rst = 0; #(BIT_NS);
        check("A", 0);  // 과제6: 일반 문자는 출력만, LED 유지
        check("1", 1);  // 켜기
        check("1", 1);  // 반복해도 계속 켜짐
        check("2", 0);  // 반전
        check("2", 1);  // 다시 반전
        check("x", 1);  // 그 밖의 문자: 유지
        check("0", 0);  // 끄기
        check("0", 0);  // 반복해도 꺼짐
        rst = 1; #20;
        if (led !== 0 || pc_txd !== 1) $fatal(1, "reset after data");
        $display("PASS UART LED: 8 bytes echoed, commands 0/1/2/other, reset"); $finish;
    end
    initial begin #200000; $fatal(1, "timeout"); end
endmodule
