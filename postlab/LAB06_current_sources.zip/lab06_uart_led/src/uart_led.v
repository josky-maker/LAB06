`timescale 1ns/1ps
// STM32_2 과제6·7: MCU(PC10)가 보낸 바이트를 FPGA가 받아
//   과제6: 받은 바이트를 그대로 보드 USB-UART(F6)로 PC에 출력
//   과제7: '0' 끄기, '1' 켜기, '2' 반전, 그 밖의 문자는 유지 → cmd_led
// 수신·송신 회로는 LAB3 UART 에코의 uart_rx/uart_tx를 재사용합니다.
// mcu_txd는 PC 출력과 같은 신호로, MCU PC11에 연결할 때만 사용합니다(추가 구현용).
module uart_led #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD = 9_600
) (
    input wire clk_50mhz,
    input wire rst_p,
    input wire mcu_rxd,
    output wire pc_txd,
    output wire mcu_txd,
    output wire [7:0] led
);
    localparam integer DIV = (CLK_HZ + BAUD/2) / BAUD;

    wire [7:0] rx_data;
    wire rx_valid, rx_framing_error;
    wire tx_ready;
    reg tx_valid;
    reg [7:0] tx_data;
    reg [6:0] last_data;
    reg cmd_led;

    uart_rx #(.DIV(DIV)) u_rx (
        .clk(clk_50mhz), .rst_p(rst_p), .rx(mcu_rxd),
        .data(rx_data), .valid(rx_valid), .framing_error(rx_framing_error)
    );
    uart_tx #(.DIV(DIV)) u_tx (
        .clk(clk_50mhz), .rst_p(rst_p), .valid(tx_valid), .data(tx_data),
        .ready(tx_ready), .tx(pc_txd)
    );
    assign mcu_txd = pc_txd;

    always @(posedge clk_50mhz) begin
        if (rst_p) begin
            tx_valid <= 0; tx_data <= 0; last_data <= 0; cmd_led <= 0;
        end else begin
            tx_valid <= 0;
            if (rx_valid) begin
                last_data <= rx_data[6:0];
                if (tx_ready) begin
                    tx_data <= rx_data;
                    tx_valid <= 1;
                end
                case (rx_data)
                    8'h30: cmd_led <= 1'b0;      // '0'
                    8'h31: cmd_led <= 1'b1;      // '1'
                    8'h32: cmd_led <= ~cmd_led;  // '2'
                    default: cmd_led <= cmd_led;
                endcase
            end
        end
    end

    // LED1 = 명령 LED, LED2~LED8 = 마지막으로 받은 ASCII 하위 7비트
    assign led = {cmd_led, last_data};
endmodule
