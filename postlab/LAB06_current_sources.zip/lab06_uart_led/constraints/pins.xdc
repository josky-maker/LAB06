# Combo II-DLD (xc7s75fgga484-1) / MAIN CLOCK 50 MHz / 9600 8N1 / 보드 최상위: uart_led
# 출처: lab00/Xilinx S7 Pin Map.xlsx (DLD-Spartan7-Peripheral), LAB3 UART 에코 XDC
# rst_p = KEY01(1번, SW4는 PUSH SWITCH)
# mcu_rxd = BDIO00(F8) ← 점퍼선 ← STM32 PC10(UART3 TX). PORT A ENABLE 스위치 ON, GND 공통.
# pc_txd  = USB_TXD0(F6) → 보드 내부 USB-UART → PC (LAB3과 같은 출력)
# mcu_txd = BDIO01(E8) → STM32 PC11 (응답까지 받을 때만 연결, 이번 과제에서는 선택)
set_property PACKAGE_PIN B6 [get_ports clk_50mhz]
set_property PACKAGE_PIN K4 [get_ports rst_p]

set_property PACKAGE_PIN F8 [get_ports mcu_rxd]
set_property PACKAGE_PIN F6 [get_ports pc_txd]
set_property PACKAGE_PIN E8 [get_ports mcu_txd]

# led[7] = LED_D1 = 명령 LED, led[6:0] = LED_D2~D8 = 마지막 수신 ASCII 하위 7비트
set_property PACKAGE_PIN L4 [get_ports {led[7]}]
set_property PACKAGE_PIN M4 [get_ports {led[6]}]
set_property PACKAGE_PIN M2 [get_ports {led[5]}]
set_property PACKAGE_PIN N7 [get_ports {led[4]}]
set_property PACKAGE_PIN M7 [get_ports {led[3]}]
set_property PACKAGE_PIN M3 [get_ports {led[2]}]
set_property PACKAGE_PIN M1 [get_ports {led[1]}]
set_property PACKAGE_PIN N5 [get_ports {led[0]}]

set_property IOSTANDARD LVCMOS33 [get_ports *]
# 점퍼선 입력이 끊겼을 때 떠 있지 않도록 풀업(UART 대기 = HIGH)
set_property PULLUP true [get_ports mcu_rxd]
create_clock -name clk_50mhz -period 20.000 [get_ports clk_50mhz]
set_false_path -from [get_ports {rst_p mcu_rxd}]
