`timescale 1ns/1ps
// LAB06 과제6 보드 진단용 최상위. uart_led와 같은 핀을 쓰고 LED에 보드 상태를 표시합니다.
// 리셋 입력(rst_p)에 의존하지 않도록 수신 회로는 전원 인가 후 내부 리셋만 사용합니다.
//   D1 led[7]: 클록 확인. 50 MHz이면 1초 주기로 깜빡임(0.5초 켜짐/0.5초 꺼짐)
//   D2 led[6]: 키패드 1번(K4, rst_p) 현재 값. 누를 때만 켜져야 정상
//   D3 led[5]: BDIO00(F8, mcu_rxd) 현재 값. UART 대기 상태는 HIGH이므로 평소 켜짐
//   D4 led[4]: F8 하강 에지(시작 비트)가 들어올 때마다 반전
//   D5~D8 led[3:0]: 마지막으로 받은 바이트의 하위 4비트
module uart_diag #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD = 9_600
) (
    input wire clk_50mhz,
    input wire rst_p,
    input wire mcu_rxd,
    output wire pc_txd,
    output wire mcu_txd,
    output wire [7:0] led
);
    localparam integer DIV = (CLK_HZ + BAUD/2) / BAUD;

    reg [3:0] por = 4'hF;          // 전원 인가 직후 짧은 내부 리셋
    wire rst_int = por != 0;
    always @(posedge clk_50mhz) if (por != 0) por <= por - 1'b1;

    reg [25:0] blink_count = 0;
    reg blink = 0;
    always @(posedge clk_50mhz)
        if (blink_count == CLK_HZ/2 - 1) begin blink_count <= 0; blink <= ~blink; end
        else blink_count <= blink_count + 1'b1;

    (* ASYNC_REG="TRUE" *) reg [2:0] rx_sync = 3'b111;
    (* ASYNC_REG="TRUE" *) reg [1:0] rst_sync = 2'b00;
    reg edge_flag = 0;
    always @(posedge clk_50mhz) begin
        rx_sync <= {rx_sync[1:0], mcu_rxd};
        rst_sync <= {rst_sync[0], rst_p};
        if (rx_sync[2] && !rx_sync[1]) edge_flag <= ~edge_flag;
    end

    wire [7:0] rx_data;
    wire rx_valid, rx_framing_error;
    wire tx_ready;
    reg tx_valid = 0;
    reg [7:0] tx_data = 0;
    reg [3:0] last_low = 0;
    uart_rx #(.DIV(DIV)) u_rx (
        .clk(clk_50mhz), .rst_p(rst_int), .rx(mcu_rxd),
        .data(rx_data), .valid(rx_valid), .framing_error(rx_framing_error)
    );
    uart_tx #(.DIV(DIV)) u_tx (
        .clk(clk_50mhz), .rst_p(rst_int), .valid(tx_valid), .data(tx_data),
        .ready(tx_ready), .tx(pc_txd)
    );
    assign mcu_txd = pc_txd;
    always @(posedge clk_50mhz) begin
        tx_valid <= 0;
        if (rx_valid) begin
            last_low <= rx_data[3:0];
            if (tx_ready) begin tx_data <= rx_data; tx_valid <= 1; end
        end
    end

    assign led = {blink, rst_sync[1], rx_sync[2], edge_flag, last_low};
endmodule
