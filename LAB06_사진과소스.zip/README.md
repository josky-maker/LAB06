# LAB06 실험 전 보고서와 검증 자료

전자전기컴퓨터설계실험Ⅱ · 2026년 10월 26일 실험 준비

## 구성
- `evidence/originals`: 제공된 Word 파일에서 추출한 원본 사진 11장
- `evidence/report_crops`: 보고서에 사용한 파형 및 빌드 화면 발췌본
- `evidence/manifest.json`: 그림 번호와 원본 파일 대응, SHA-256
- `lab06_servo`, `lab06_sram`, `lab06_dac`, `lab06_uart_led`: 제공된 RTL, TB, 핀 제약과 기존 검증 로그·VCD
- `stm32/variants`: STM32 UART 과제 5·6·7 소스
- `reports`: 최종 PDF

## 검증 범위
저장된 FPGA 로그는 PASS를 기록한다. 이번 보고서 작성 중 시뮬레이션을 다시 실행한 것은 아니다. STM32 화면은 증분 빌드 종료 코드 0이며 실제 UART 통신이나 보드 동작을 증명하지 않는다.

FPGA `evidence`에는 원래 build/sim의 로그·VCD를 보존했다. 소스의 원래 경로는 로컬 LAB06 폴더이며 보고서는 파일의 실제 내용과 사진을 대조해 작성했다. 전체 STM32 수업 기본 프로젝트는 제공되지 않으며 variants 파일을 해당 수업 프로젝트에 적용한다.

## 제출 버전
최종 보고서 포함 버전은 `prelab-v1.0.0` 태그로 고정한다. 보고서에 기록한 소스 기준 커밋은 사진·코드·TB·검증 자료를 고정한 선행 커밋이다.
